# finalproject_industry4

# LNC controller and set up a database!

:::info

Admin: Cyanlin AstraLee



:::
